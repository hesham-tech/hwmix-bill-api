<?php

return [
    'name' => 'Companies',
];
