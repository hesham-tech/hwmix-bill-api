<?php

return [
    'name' => 'Sales',
];
