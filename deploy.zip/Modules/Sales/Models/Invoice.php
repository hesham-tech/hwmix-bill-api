<?php

namespace Modules\Sales\Models;

use App\Traits\Blameable;
use App\Traits\LogsActivity;
use App\Traits\Scopes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\Attributes\ObservedBy;
use Modules\Sales\Observers\InvoiceObserver;
use App\Traits\SmartSearch;
use App\Models\User;
use App\Models\Company;
use App\Models\InstallmentPlan;

/**
 *   كلاس يمثل الفواتير بمختلف أنواعها (بيع، شراء، مرتجعات) داخل موديول المبيعات.
 */
#[ObservedBy([InvoiceObserver::class])]
class Invoice extends Model
{
    use HasFactory, LogsActivity, Blameable, Scopes, SoftDeletes, SmartSearch, \App\Traits\FilterableByBranch;

    protected $guarded = [];

    protected static function newFactory()
    {
        return \Database\Factories\InvoiceFactory::new();
    }

    /**
     * Label for activity logs.
     */
    public function logLabel()
    {
        $typeName = $this->invoiceType?->name ?? 'فاتورة';
        return "{$typeName} رقم #{$this->invoice_number} بمبلغ: {$this->net_amount}";
    }

    protected $casts = [
        'total_tax' => 'decimal:2',
        'tax_rate' => 'decimal:2',
        'tax_inclusive' => 'boolean',
        'issue_date' => 'date',
        'due_date' => 'date',
        'previous_balance' => 'decimal:2',
        'initial_paid_amount' => 'decimal:2',
        'initial_remaining_amount' => 'decimal:2',
        'user_balance_after' => 'decimal:2',
        'is_aggregated' => 'boolean',
    ];

    // Status Constants
    const STATUS_DRAFT = 'draft';
    const STATUS_CONFIRMED = 'confirmed';
    const STATUS_PAID = 'paid';
    const STATUS_PARTIALLY_PAID = 'partially_paid';
    const STATUS_OVERDUE = 'overdue';
    const STATUS_CANCELED = 'canceled';
    const STATUS_REFUNDED = 'refunded';

    // Payment Status Constants
    const PAYMENT_UNPAID = 'unpaid';
    const PAYMENT_PARTIALLY_PAID = 'partially_paid';
    const PAYMENT_PAID = 'paid';
    const PAYMENT_OVERPAID = 'overpaid';

    /**
     * تحديث حالة الدفع بناءً على المبالغ
     */
    public function updatePaymentStatus(): void
    {
        if ($this->paid_amount == 0) {
            $this->payment_status = self::PAYMENT_UNPAID;
        } elseif ($this->paid_amount >= $this->net_amount) {
            $this->payment_status = $this->paid_amount > $this->net_amount
                ? self::PAYMENT_OVERPAID
                : self::PAYMENT_PAID;
        } else {
            $this->payment_status = self::PAYMENT_PARTIALLY_PAID;
        }

        $this->save();
    }

    protected static function booted()
    {
        static::creating(function ($invoice) {
            $type = InvoiceType::find($invoice->invoice_type_id);
            if ($type) {
                $invoice->invoice_type_code = $invoice->invoice_type_code ?? $type->code;
            }

            if (empty($invoice->invoice_number)) {
                $companyId = Auth::user() ? Auth::user()->active_company_id : ($invoice->company_id ?? null);
                $invoice->invoice_number = self::generateInvoiceNumber($type?->code ?? 'INV', $companyId);
            }

            $invoice->company_id = $invoice->company_id ?? (Auth::user() ? Auth::user()->active_company_id : null);
            $invoice->branch_id = $invoice->branch_id ?? config('app.active_branch_id') ?? (Auth::user() ? Auth::user()->branch_id : null);
            $invoice->created_by = $invoice->created_by ?? Auth::id();

            if (empty($invoice->issue_date)) {
                $invoice->issue_date = now();
            }

            if (empty($invoice->due_date)) {
                $baseDate = $invoice->issue_date ? \Carbon\Carbon::parse($invoice->issue_date) : now();
                $invoice->due_date = $baseDate->copy()->addMonths(6);
            }

            $invoice->initial_paid_amount = $invoice->paid_amount ?? 0;
            $invoice->initial_remaining_amount = $invoice->remaining_amount ?? 0;
        });

        static::updating(function ($invoice) {
            $invoice->updated_by = Auth::id();
        });
    }

    public static function generateInvoiceNumber($typeCode, $companyId)
    {
        $datePart = now()->format('ymd');
        $lastInvoice = self::where('company_id', $companyId)
            ->whereHas('invoiceType', fn($query) => $query->where('code', $typeCode))
            ->latest('id')
            ->first();
        $lastSerial = $lastInvoice ? (int) substr($lastInvoice->invoice_number, -6) : 0;
        $nextSerial = str_pad($lastSerial + 1, 6, '0', STR_PAD_LEFT);
        return strtoupper(self::shortenTypeCode($typeCode)) . '-' . $datePart . '-' . $companyId . '-' . $nextSerial;
    }

    public static function shortenTypeCode(string $typeCode): string
    {
        $parts = explode('_', $typeCode);
        return count($parts) === 1
            ? substr($typeCode, 0, 4)
            : implode('_', array_map(fn($p) => substr($p, 0, 3), $parts));
    }

    public function customer()
    {
        return $this->belongsTo(User::class, 'user_id')->withoutGlobalScopes();
    }
    public function invoiceType()
    {
        return $this->belongsTo(InvoiceType::class);
    }
    public function items()
    {
        return $this->hasMany(InvoiceItem::class);
    }
    public function itemsWithTrashed()
    {
        return $this->hasMany(InvoiceItem::class)->withTrashed();
    }
    public function company()
    {
        return $this->belongsTo(Company::class);
    }
    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by')->withoutGlobalScopes();
    }
    public function updater()
    {
        return $this->belongsTo(User::class, 'updated_by')->withoutGlobalScopes();
    }
    public function installmentPlan()
    {
        return $this->hasOne(InstallmentPlan::class, 'invoice_id');
    }

    public function payments()
    {
        return $this->hasMany(InvoicePayment::class, 'invoice_id');
    }

    public function warehouse()
    {
        return $this->belongsTo(\Modules\Inventory\Models\Warehouse::class, 'warehouse_id');
    }

    public function toWarehouse()
    {
        return $this->belongsTo(\Modules\Inventory\Models\Warehouse::class, 'to_warehouse_id');
    }

    public function getIssueDateColumn(): string
    {
        return 'issue_date';
    }
}
