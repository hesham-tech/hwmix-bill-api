<?php

namespace Modules\Sales\Http\Resources;

use App\Http\Resources\User\UserBasicResource;
use App\Http\Resources\Company\CompanyResource;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\InstallmentPlan\InstallmentPlanBasicResource;

class InvoiceResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'invoice_type_id' => $this->invoice_type_id,
            'invoice_number' => $this->invoice_number,
            'gross_amount' => number_format($this->gross_amount, 2, '.', ''),
            'paid_amount' => number_format($this->paid_amount, 2, '.', ''),
            'remaining_amount' => number_format($this->remaining_amount, 2, '.', ''),
            'previous_balance' => number_format($this->previous_balance, 2, '.', ''),
            'total_required' => number_format($this->net_amount - $this->previous_balance, 2, '.', ''),
            'round_step' => $this->round_step,
            'net_amount' => number_format($this->net_amount, 2, '.', ''),
            'total_discount' => number_format($this->total_discount, 2, '.', ''),
            'initial_paid_amount' => number_format($this->initial_paid_amount, 2, '.', ''),
            'initial_remaining_amount' => number_format($this->initial_remaining_amount, 2, '.', ''),
            'user_balance_after' => number_format($this->user_balance_after, 2, '.', ''),

            'status' => $this->status,
            'status_label' => $this->getStatusLabel(),
            'payment_status' => $this->payment_status,
            'payment_status_label' => $this->getPaymentStatusLabel(),
            'notes' => $this->notes,
            'cash_box_id' => $this->cash_box_id,
            'warehouse_id' => $this->warehouse_id,
            'to_warehouse_id' => $this->to_warehouse_id,
            'reference_number' => $this->reference_number,

            'issue_date' => $this->issue_date ? $this->issue_date->format('Y-m-d') : null,
            'due_date' => $this->due_date ? $this->due_date->format('Y-m-d') : null,
            'created_at' => optional($this->created_at)->format('Y-m-d H:i:s'),
            'updated_at' => optional($this->updated_at)->format('Y-m-d H:i:s'),

            'customer' => new UserBasicResource($this->whenLoaded('customer')),
            'invoice_type' => new InvoiceTypeResource($this->whenLoaded('invoiceType')),
            'items' => $this->whenLoaded('items', fn() => InvoiceItemResource::collection($this->items)),
            'payments' => $this->whenLoaded('payments', function () {
                return InvoicePaymentResource::collection($this->payments);
            }),
            'company' => new CompanyResource($this->whenLoaded('company')),
            'creator' => new UserBasicResource($this->whenLoaded('creator')),
            'installment_plan' => new InstallmentPlanBasicResource($this->whenLoaded('installmentPlan')),
            'warehouse' => new \Modules\Inventory\Http\Resources\WarehouseResource($this->whenLoaded('warehouse')),
            'to_warehouse' => new \Modules\Inventory\Http\Resources\WarehouseResource($this->whenLoaded('toWarehouse')),

            'company_id' => $this->company_id,
            'created_by' => $this->created_by,
            'installment_plan_id' => $this->installment_plan_id,
            'user_balance' => $this->customer ? $this->customer->getFinancialBalance($this->company_id, 'receivable') : 0,
        ];
    }

    protected function getStatusLabel()
    {
        return match ($this->status) {
            'draft' => 'مسودة',
            'confirmed' => 'مؤكدة',
            'canceled' => 'ملغاة',
            'paid' => 'مدفوعة بالكامل',
            'partially_paid' => 'مدفوعة جزئياً',
            default => 'غير معروفة',
        };
    }

    protected function getPaymentStatusLabel()
    {
        return match ($this->payment_status) {
            'unpaid' => 'غير مدفوعة',
            'partially_paid' => 'مدفوعة جزئياً',
            'paid' => 'مدفوعة بالكامل',
            'overpaid' => 'مدفوعة بزيادة',
            default => 'غير معروفة',
        };
    }
}
