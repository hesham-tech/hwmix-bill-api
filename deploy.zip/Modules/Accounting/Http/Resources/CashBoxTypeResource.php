<?php

namespace Modules\Accounting\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CashBoxTypeResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'description' => $this->description,
            'is_default' => (bool) $this->is_default,
            'is_system' => (bool) $this->is_system,
            'is_active' => (bool) $this->is_active,
            'image_url' => $this->image?->url,
            'image_id' => $this->image?->id,
            'company_id' => $this->company_id,
            'created_by' => $this->created_by,
            'creator_name' => $this->creator?->nickname,
            'cash_boxes_count' => $this->cash_boxes_count ?? $this->cashBoxes()->count(),
            'created_at' => $this->created_at?->format('Y-m-d H:i:s'),
            'updated_at' => $this->updated_at?->format('Y-m-d H:i:s'),
        ];
    }
}
