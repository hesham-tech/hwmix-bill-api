<?php

namespace Modules\Inventory\Http\Controllers;

use App\Http\Controllers\Controller;
use Modules\Inventory\Http\Requests\StoreProductRequest;
use Modules\Inventory\Http\Requests\UpdateProductRequest;
use Modules\Inventory\Http\Resources\ProductResource;
use Modules\Inventory\Models\Product;
use Modules\Inventory\Models\Stock;
use Modules\Inventory\Services\ProductService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * @group إدارة المنتجات (Module Inventory)
 */
class ProductController extends Controller
{
    protected array $indexRelations = ['category', 'brand', 'images', 'variants'];
    protected array $showRelations = [
        'company', 'creator', 'category', 'brand', 'images', 
        'variants.images', 'variants.stocks.warehouse', 
        'variants.attributes.attribute', 'variants.attributes.attributeValue'
    ];

    protected ProductService $productService;

    public function __construct(ProductService $productService)
    {
        $this->productService = $productService;
    }

    /**
     * عرض قائمة المنتجات
     */
    public function index(Request $request): JsonResponse
    {
        try {
            $authUser = Auth::user();
            $query = Product::query();

            // تطبيق الحسابات التجميعية
            $query->withMin('variants', 'retail_price')
                ->withMax('variants', 'retail_price')
                ->addSelect([
                    'total_available_quantity' => Stock::selectRaw('IFNULL(SUM(quantity), 0)')
                        ->join('product_variants', 'stocks.variant_id', '=', 'product_variants.id')
                        ->whereColumn('product_variants.product_id', 'products.id')
                        ->where('stocks.status', '=', 'available')
                ]);

            // تصفية الصلاحيات
            if (!$authUser->hasPermissionTo(perm_key('admin.super'))) {
                $query->whereCompanyIsCurrent();
            }

            // التصفية والبحث
            if ($request->filled('search')) {
                $search = $request->search;
                $query->where(function ($q) use ($search) {
                    $q->where('name', 'like', "%$search%")
                        ->orWhere('desc', 'like', "%$search%")
                        ->orWhereHas('category', fn($cq) => $cq->where('name', 'like', "%$search%"))
                        ->orWhereHas('brand', fn($bq) => $bq->where('name', 'like', "%$search%"));
                });
            }

            if ($request->boolean('in_store')) {
                $query->inStore();
            }

            if ($request->boolean('in_sales')) {
                $query->inSales();
            }

            $perPage = max(1, (int) $request->get('per_page', 20));
            $products = $query->with($this->indexRelations)->orderBy('created_at', 'desc')->paginate($perPage);

            return api_success(ProductResource::collection($products), 'تم استرداد المنتجات بنجاح.');
        } catch (Throwable $e) {
            return api_exception($e);
        }
    }

    /**
     * إضافة منتج جديد
     */
    public function store(StoreProductRequest $request): JsonResponse
    {
        try {
            /** @var \App\Models\User $authUser */
            $authUser = Auth::user();
            $companyId = $authUser->active_company_id;

            $product = $this->productService->createProduct($request->toSimpleProductData(), $authUser, $companyId);

            return api_success(new ProductResource($product->load($this->showRelations)), 'تم إنشاء المنتج بنجاح.', 201);
        } catch (Throwable $e) {
            return api_exception($e);
        }
    }

    /**
     * عرض تفاصيل منتج
     */
    public function show(Product $product): JsonResponse
    {
        try {
            $authUser = Auth::user();
            if (!$authUser->hasPermissionTo(perm_key('admin.super')) && $product->company_id !== $authUser->active_company_id) {
                return api_forbidden('ليس لديك صلاحية لعرض هذا المنتج.');
            }
            $product->load($this->showRelations);
            return api_success(new ProductResource($product), 'تم استرداد بيانات المنتج بنجاح.');
        } catch (Throwable $e) {
            return api_exception($e);
        }
    }

    /**
     * تحديث بيانات منتج
     */
    public function update(UpdateProductRequest $request, Product $product): JsonResponse
    {
        try {
            /** @var \App\Models\User $authUser */
            $authUser = Auth::user();
            if (!$authUser->hasPermissionTo(perm_key('admin.super')) && $product->company_id !== $authUser->active_company_id) {
                return api_forbidden('ليس لديك صلاحية لتعديل هذا المنتج.');
            }
            $product = $this->productService->updateProduct($product, $request->toSimpleProductData(), $authUser);

            return api_success(new ProductResource($product->load($this->showRelations)), 'تم تحديث المنتج بنجاح.');
        } catch (Throwable $e) {
            return api_exception($e);
        }
    }

    /**
     * حذف منتج
     */
    public function destroy(Product $product): JsonResponse
    {
        try {
            $authUser = Auth::user();
            if (!$authUser->hasPermissionTo(perm_key('admin.super')) && $product->company_id !== $authUser->active_company_id) {
                return api_forbidden('ليس لديك صلاحية لحذف هذا المنتج.');
            }
            DB::beginTransaction();
            foreach ($product->variants as $variant) {
                $variant->attributes()->delete();
                $variant->stocks()->delete();
                $variant->delete();
            }
            $product->delete();
            DB::commit();

            return api_success([], 'تم حذف المنتج بنجاح.');
        } catch (Throwable $e) {
            DB::rollBack();
            return api_exception($e);
        }
    }

    /**
     * حذف منتجات متعددة دفعة واحدة
     */
    public function deleteMultiple(Request $request): JsonResponse
    {
        try {
            /** @var \App\Models\User $authUser */
            $authUser = Auth::user();
            $companyId = $authUser->active_company_id ?? null;

            if (!$authUser) {
                return api_unauthorized('يتطلب المصادقة.');
            }
            if (!$companyId) {
                return api_forbidden('يتطلب الارتباط بالشركة.');
            }

            if (!$authUser->hasPermissionTo(perm_key('admin.super')) && !$authUser->hasAnyPermission([
                perm_key('products.delete_all'),
                perm_key('admin.company'),
                perm_key('products.delete_children'),
                perm_key('products.delete_self')
            ])) {
                return api_forbidden('ليس لديك صلاحية لحذف المنتجات.');
            }

            $request->validate([
                'ids' => 'required|array',
                'ids.*' => 'integer|exists:products,id',
            ]);

            $idsToDelete = $request->input('ids');
            $cannotDelete = [];

            DB::beginTransaction();
            try {
                $deletedCount = 0;
                foreach ($idsToDelete as $id) {
                    $product = Product::with(['variants.stocks'])->find($id);

                    if ($product) {
                        $canDelete = false;
                        if ($authUser->hasPermissionTo(perm_key('admin.super'))) {
                            $canDelete = true;
                        } elseif ($authUser->hasAnyPermission([perm_key('products.delete_all'), perm_key('admin.company')])) {
                            $canDelete = ($product->company_id === $companyId);
                        } elseif ($authUser->hasPermissionTo(perm_key('products.delete_children'))) {
                            $canDelete = ($product->company_id === $companyId) && $product->createdByUserOrChildren();
                        } elseif ($authUser->hasPermissionTo(perm_key('products.delete_self'))) {
                            $canDelete = ($product->company_id === $companyId) && ($product->created_by === $authUser->id);
                        }

                        if ($canDelete) {
                            $hasStock = false;
                            foreach ($product->variants as $variant) {
                                if ($variant->stocks()->sum('quantity') > 0) {
                                    $hasStock = true;
                                    break;
                                }
                            }

                            if ($hasStock) {
                                $cannotDelete[] = $product->id;
                            } else {
                                foreach ($product->variants as $variant) {
                                    $variant->attributes()->delete();
                                    $variant->stocks()->delete();
                                    $variant->delete();
                                }
                                $product->delete();
                                $deletedCount++;
                            }
                        }
                    }
                }

                if (!empty($cannotDelete)) {
                    DB::rollBack();
                    return api_error('بعض المنتجات لا يمكن حذفها لوجود كميات مخزنية مرتبطة بها.', ['ids_with_stock' => $cannotDelete], 409);
                }

                DB::commit();
                return api_success([], "تم حذف {$deletedCount} منتج بنجاح.");
            } catch (Throwable $e) {
                DB::rollBack();
                return api_exception($e);
            }
        } catch (Throwable $e) {
            return api_exception($e);
        }
    }
}
