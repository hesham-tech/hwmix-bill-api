<?php

namespace App\Http\Controllers;

use Throwable;
use App\Models\User;
use App\Models\CompanyUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\User\UserRequest;
use App\Http\Resources\User\UserResource;
use App\Http\Requests\User\UserUpdateRequest;
use App\Http\Resources\CompanyUser\CompanyUserResource;
use App\Http\Resources\CompanyUser\CompanyUserBasicResource;
use App\Http\Resources\User\UserWithPermissionsResource;
use App\Models\CashBoxType;
use App\Actions\User\RegisterInternalUserAction;


class UserController extends Controller
{
    private array $relations;

    public function __construct()
    {
        $this->relations = [
            'companies.logo',
            'cashBoxes',
            'creator',
            'companies',
            'activeCompanyUser.company',
            'branches',
        ];
    }

    /**
     * @group 07. الإدارة وسجلات النظام
     * 
     * عرض قائمة المستخدمين
     * 
     * @queryParam nickname string فلترة حسب اللقب.
     * @queryParam phone string فلترة حسب الهاتف.
     * @queryParam per_page integer عدد النتائج.
     * 
     * @apiResourceCollection App\Http\Resources\CompanyUser\CompanyUserResource
     * @apiResourceModel App\Models\CompanyUser
     */
    /**
     * @group 07. الإدارة وسجلات النظام
     * 
     * عرض قائمة المستخدمين (عالمياً للسوبر أدمن، أو حسب الشركة للمديرين)
     */
    public function index(Request $request)
    {
        $authUser = Auth::user();
        try {
            if (!$authUser) {
                return api_unauthorized();
            }

            $activeCompanyId = $authUser->active_company_id;
            $isSuperAdmin = $authUser->can(perm_key('admin.super'));
            $isCompanyAdmin = $authUser->hasPermissionTo(perm_key('admin.company'));
            $canViewAll = $authUser->hasPermissionTo(perm_key('users.view_all'));
            $canViewChildren = $authUser->hasPermissionTo(perm_key('users.view_children'));

            // تحديد إذا كان المطلوب هو العرض العالمي (للسوبر أدمن فقط)
            $isGlobalView = filter_var($request->input('global', false), FILTER_VALIDATE_BOOLEAN) && $isSuperAdmin;

            // فلتر: المستخدمون غير التابعين لأي شركة (active_company_id = null)
            $isUnaffiliated = filter_var($request->input('unaffiliated', false), FILTER_VALIDATE_BOOLEAN) && $isSuperAdmin;

            if ($isUnaffiliated) {
                // جلب المستخدمين الذين ليس لديهم شركة نشطة
                $query = User::query()
                    ->withoutGlobalScope('company_filter')
                    ->withoutGlobalScope('branch_filter')
                    ->with(['company', 'companies.logo', 'creator', 'roles', 'permissions', 'images', 'cashBoxes', 'branches'])
                    ->whereNull('active_company_id');
            } elseif ($isGlobalView) {
                // العرض العالمي: جلب سجلات فريدة من جدول users
                $query = User::query()
                    ->withoutGlobalScope('company_filter')
                    ->withoutGlobalScope('branch_filter')
                    ->with(['company', 'companies.logo', 'creator', 'roles', 'permissions', 'images', 'cashBoxes', 'branches']);

                // استبعاد العملاء النقديين لجميع الشركات عند عدم البحث
                if (!$request->filled('search')) {
                    $query->whereDoesntHave('companyUsers', function ($q) {
                        $q->where('customer_type_in_company', 'cash_customer');
                    });
                }
            } else {
                // العرض السياقي: جلب سجلات من company_user
                if (!$activeCompanyId && !$isSuperAdmin) {
                    return api_forbidden('يجب تحديد شركة نشطة.');
                }

                $query = CompanyUser::with([
                    'user' => fn($q) => $q->with(['creator', 'companies.logo', 'roles', 'permissions', 'images', 'cashBoxes', 'branches']),
                    'company',
                ]);

                if (!$isSuperAdmin) {
                    $query->where('company_id', $activeCompanyId);

                    if (!$isCompanyAdmin && !$canViewAll) {
                        if ($canViewChildren) {
                            $descendantUserIds = $authUser->getDescendantUserIds();
                            $query->whereIn('user_id', $descendantUserIds);
                        } else {
                            return api_forbidden('ليس لديك صلاحية لعرض المستخدمين.');
                        }
                    }
                }

                // استبعاد المستخدم الحالي من القائمة الإدارية
                $query->where('user_id', '!=', $authUser->id);

                // استبعاد جميع المستخدمين من النوع نقدي (العملاء النقديين) عند عدم البحث
                if (!$request->filled('search')) {
                    $query->where('customer_type_in_company', '!=', 'cash_customer');
                }
            }

            // تطبيق البحث الذكي (Smart Search)
            if ($request->filled('search')) {
                $search = $request->input('search');

                if ($isGlobalView || $isUnaffiliated) {
                    // البحث العالمي للمشرف العام
                    $columns = ['username', 'email', 'phone', 'full_name', 'nickname'];
                    $query->smartSearch($search, $columns);
                } else {
                    // البحث السياقي داخل الشركة
                    $columns = ['nickname_in_company', 'full_name_in_company'];
                    $relationColumns = [
                        'user' => ['email', 'phone', 'username', 'full_name', 'nickname']
                    ];
                    $query->smartSearch($search, $columns, $relationColumns);
                }
            }

            // فلترة حسب نوع العميل
            if ($request->filled('customer_type')) {
                $customerType = $request->input('customer_type');
                if ($isGlobalView) {
                    $query->whereHas('companyUsers', function ($q) use ($customerType, $activeCompanyId) {
                        $q->where('customer_type_in_company', $customerType);
                        if ($activeCompanyId) {
                            $q->where('company_id', $activeCompanyId);
                        }
                    });
                } else {
                    $query->where('customer_type_in_company', $customerType);
                }
            }

            // فلترة حسب تصنيف المستخدم (موظف / عميل)
            if ($request->filled('user_type')) {
                $userType = $request->input('user_type');
                
                $userFilterCallback = function ($q) use ($userType) {
                    if ($userType === 'staff') {
                        $q->where(function($subQ) {
                            $subQ->has('roles')->orHas('permissions');
                        });
                    } elseif ($userType === 'customer') {
                        $q->doesntHave('roles')->doesntHave('permissions');
                    }
                };

                if ($isGlobalView || $isUnaffiliated) {
                    $query->where($userFilterCallback);
                } else {
                    $query->whereHas('user', $userFilterCallback);
                }
            }

            // فلترة حسب العلاقة التجارية (Business Relation)
            if ($request->filled('relation_type')) {
                $relationType = $request->input('relation_type');
                if ($isGlobalView) {
                    $query->whereHas('businessRelations', function ($q) use ($relationType, $activeCompanyId) {
                        $q->where('relation_type', $relationType);
                        if ($activeCompanyId) {
                            $q->where('company_id', $activeCompanyId);
                        }
                    });
                } else {
                    $query->whereHas('user.businessRelations', function ($q) use ($relationType, $activeCompanyId) {
                        $q->where('relation_type', $relationType);
                        if ($activeCompanyId) {
                            $q->where('company_id', $activeCompanyId);
                        }
                    });
                }
            }

            // تحديد عدد العناصر في الصفحة والفرز
            $perPage = max(1, $request->input('per_page', 10));
            $sortField = $request->input('sort_by');
            if (empty($sortField)) {
                $sortField = $isGlobalView ? 'created_at' : 'sales_count';
            }
            $sortOrder = $request->input('sort_order', 'desc');

            $query->orderBy($sortField, $sortOrder);
            if ($sortField !== 'created_at') {
                $query->orderBy('created_at', 'desc');
            }

            /** @var \Illuminate\Pagination\LengthAwarePaginator $data */
            $data = $query->paginate($perPage);

            // تحسين النتائج باستخدام التشابه (Similarity Matching) بنسبة 80%
            if ($request->filled('search')) {
                $search = $request->input('search');
                $items = $data->getCollection();

                if ($isGlobalView) {
                    $fieldsToCompare = ['username', 'email', 'phone', 'full_name', 'nickname'];
                    $refined = (new User())->refineSimilarity($items, $search, $fieldsToCompare, 80);
                } else {
                    $fieldsToCompare = [
                        'nickname_in_company',
                        'full_name_in_company',
                        'user.email',
                        'user.phone',
                        'user.username',
                        'user.full_name',
                        'user.nickname'
                    ];
                    $refined = (new CompanyUser())->refineSimilarity($items, $search, $fieldsToCompare, 80);
                }

                if ($refined instanceof \Illuminate\Support\Collection && !$refined->isEmpty()) {
                    $data->setCollection($refined);
                }
            }

            $resourceClass = ($isGlobalView || $isUnaffiliated) ? UserResource::class : CompanyUserBasicResource::class;

            if (is_null($data)) {
                return api_success([], 'لا توجد بيانات متاحة.');
            }

            return api_success($resourceClass::collection($data), 'تم جلب البيانات بنجاح.');
        } catch (Throwable $e) {
            return api_exception($e);
        }
    }

    /**
     * @group 07. الإدارة وسجلات النظام
     * 
     * عرض قائمة الموظفين (عالمياً للسوبر أدمن، أو حسب الشركة للمديرين)
     */
    public function staff(Request $request)
    {
        $request->merge(['user_type' => 'staff']);
        return $this->index($request);
    }

    /**
     * @group 07. الإدارة وسجلات النظام
     * 
     * عرض قائمة العملاء (عالمياً للسوبر أدمن، أو حسب الشركة للمديرين)
     */
    public function customers(Request $request)
    {
        $request->merge(['user_type' => 'customer']);
        return $this->index($request);
    }

    /**
     * @group 07. الإدارة وسجلات النظام
     * 
     * البحث عن مستخدم موجود مسبقاً في النظام (بناءً على الهاتف أو الإيميل)
     * 
     * @queryParam phone string رقم الهاتف للبحث.
     * @queryParam email string البريد الإلكتروني للبحث.
     */
    public function lookup(Request $request)
    {
        try {
            $request->validate([
                'phone' => 'nullable|string',
                'email' => 'nullable|string|email',
            ]);

            if (!$request->filled('phone') && !$request->filled('email')) {
                return api_error('يجب إدخال رقم الهاتف أو البريد الإلكتروني للبحث.', [], 400);
            }

            $query = User::withoutGlobalScope('company');

            $query->where(function ($q) use ($request) {
                if ($request->filled('phone')) {
                    $q->where('phone', $request->phone);
                }
                if ($request->filled('email')) {
                    if ($request->filled('phone')) {
                        $q->orWhere('email', $request->email);
                    } else {
                        $q->where('email', $request->email);
                    }
                }
            });

            $user = $query->with([
                'companies' => function ($q) {
                    $q->select('companies.id', 'companies.name');
                }
            ])->first();

            if (!$user) {
                return api_success(null, 'المستخدم غير موجود مسبقاً.');
            }

            return api_success([
                'id' => $user->id,
                'username' => $user->username,
                'email' => $user->email,
                'phone' => $user->phone,
                'name' => $user->name,
                'nickname' => $user->nickname,
                'full_name' => $user->full_name,
                'avatar_url' => $user->avatar_url,
                'companies' => $user->companies->map(fn($c) => [
                    'id' => $c->id,
                    'name' => $c->name,
                    'is_in_current_company' => $c->id == (Auth::user()->active_company_id ?? null)
                ])
            ], 'تم العثور على بيانات المستخدم في النظام.');
        } catch (Throwable $e) {
            return api_exception($e);
        }
    }

    /**
     * @group 07. الإدارة وسجلات النظام
     * 
     * إضافة مستخدم جديد
     */
    public function store(UserRequest $request, RegisterInternalUserAction $action)
    {
        try {
            $companyUser = $action->execute(
                $request->validated(),
                Auth::user()->active_company_id,
                Auth::user()
            );

            return api_success(
                new CompanyUserResource($companyUser->load('user', 'company')),
                'تمت إضافة المستخدم بنجاح.'
            );

        } catch (Throwable $e) {
            return api_exception($e);
        }
    }
    /**
     * @group 07. الإدارة وسجلات النظام
     * 
     * عرض تفاصيل مستخدم
     * 
     * @urlParam user required معرف المستخدم. Example: 1
     * 
     * @apiResource App\Http\Resources\User\UserResource
     * @apiResourceModel App\Models\User
     */
    public function show(User $user, Request $request)
    {
        $authUser = Auth::user();
        if (!$authUser) {
            return api_unauthorized('يجب تسجيل الدخول.');
        }

        // التعرف على البراميترات بأكثر من طريقة لضمان الدقة
        $withPermissions = $request->has('permissions') && ($request->input('permissions') == 1 || $request->input('permissions') == 'true');
        $syncCompanyId = $request->input('sync_company_id');
        $activeCompanyId = $syncCompanyId ?? $authUser->active_company_id;
        $isSuperAdmin = $authUser->can(perm_key('admin.super'));
        $useBasicResource = filter_var($request->input('basic', true), FILTER_VALIDATE_BOOLEAN);

        if ($activeCompanyId) {
            setPermissionsTeamId($activeCompanyId);
        }

        // 1. التحقق من صلاحية العرض العامة
        $canViewAll = $authUser->hasPermissionTo(perm_key('users.view_all'));
        $isCompanyAdmin = $authUser->hasPermissionTo(perm_key('admin.company'));
        $canViewChildren = $authUser->hasPermissionTo(perm_key('users.view_children'));
        $isUpdatingSelf = ($authUser->id === $user->id);

        $hasAccess = $isSuperAdmin || $isUpdatingSelf || $isCompanyAdmin || $canViewAll || ($canViewChildren && in_array($user->id, $authUser->getDescendantUserIds()));

        if (!$hasAccess) {
            return api_forbidden('ليس لديك صلاحية لعرض هذا المستخدم.');
        }

        // 2. إذا كان المطلوب هو ريسورس الصلاحيات التفصيلي (الأولوية القصوى)
        if ($withPermissions) {
            // تحميل العلاقات الأساسية + الصلاحيات لضمان عمل الفلترة بشكل صحيح في الواجهة الأمامية
            $user->load(array_merge($this->relations, ['roles.permissions', 'permissions']));
            return api_success(new UserWithPermissionsResource($user), 'تم جلب بيانات الصلاحيات بنجاح.');
        }

        // 3. المسار التقليدي (الملف الشخصي أو سوبر أدمن بدون صلاحيات تفصيلية)
        if ($isUpdatingSelf || $isSuperAdmin) {
            $user->load($this->relations);
            return api_success(new UserResource($user), 'تم جلب بيانات المستخدم بنجاح.');
        }

        // 4. عرض العضو داخل سياق شركة
        if ($activeCompanyId) {
            $companyUser = CompanyUser::where('user_id', $user->id)
                ->where('company_id', $activeCompanyId)
                ->with([
                    'user.cashBoxes' => function ($q) use ($activeCompanyId) {
                        $q->where('company_id', $activeCompanyId);
                    },
                    'user.creator',
                    'user.branches',
                    'user.roles',
                    'user.permissions',
                    'user.companies.logo',
                    'company'
                ])
                ->first();

            if ($companyUser) {
                $resourceClass = $useBasicResource ? CompanyUserBasicResource::class : CompanyUserResource::class;
                return api_success(new $resourceClass($companyUser), 'تم جلب بيانات العضو بنجاح.');
            }
        }

        // Fallback للرؤية العالمية للسوبر أدمن
        if ($isSuperAdmin) {
            $user->load($this->relations);
            return api_success(new UserResource($user), 'تم جلب بيانات المستخدم بنجاح (عرض عالمي).');
        }

        return api_not_found('المستخدم غير موجود في هذه الشركة.');
    }
    /**
     * @group 07. الإدارة وسجلات النظام
     * 
     * تحديث بيانات مستخدم
     * 
     * @urlParam user required معرف المستخدم. Example: 1
     */
    public function update(UserUpdateRequest $request, User $user)
    {
        $authUser = Auth::user();
        if (!$authUser)
            return api_unauthorized();

        $isSuperAdmin = $authUser->can(perm_key('admin.super'));
        $activeCompanyId = $authUser->active_company_id;

        DB::beginTransaction();
        try {
            $validated = $request->validated();

            // 1. [تعديل الهوية]: جدول users
            $isUpdatingSelf = ($authUser->id === $user->id);
            $canUpdateAll = $authUser->can(perm_key('users.update_all'));
            $canUpdateChildren = $authUser->can(perm_key('users.update_children'));
            $isDescendant = $canUpdateChildren ? in_array($user->id, $authUser->getDescendantUserIds()) : false;

            if ($isSuperAdmin || $isUpdatingSelf || $canUpdateAll || $isDescendant) {
                // إذا كان المستخدم يعدل هويته الشخصية، يسمح له بتعديل الاسم واللقب عالمياً
                // أما لو كان المشرف يعدل مستخدماً آخر، فلا نلمس الاسم واللقب في جدول users ونحدث بقية البيانات العالمية فقط (الهاتف، الإيميل، كلمة المرور)
                $allowedKeys = [
                    'username',
                    'email',
                    'phone',
                    'password',
                    'settings'
                ];
                if ($isUpdatingSelf) {
                    $allowedKeys[] = 'full_name';
                    $allowedKeys[] = 'nickname';
                    $allowedKeys[] = 'position';
                }

                $userData = array_intersect_key($validated, array_flip($allowedKeys));
                if (!empty($userData)) {
                    $user->update($userData);
                }
            }

            // 2. [تعديل العضوية]: جدول company_user
            // يتم التعديل في سياق الشركة النشطة فقط للمشرفين عند تعديل مستخدمين آخرين
            // ولا يتم تحديث جدول الوسيط للمستخدم الحالي عند تعديل ملفه الشخصي للحفاظ على استقلالية هويته
            if ($activeCompanyId && !$isUpdatingSelf) {
                $companyUser = $user->companyUsers()->where('company_id', $activeCompanyId)->first();
                if ($companyUser) {
                    $contextData = [];
                    if (isset($validated['nickname']))
                        $contextData['nickname_in_company'] = $validated['nickname'];
                    if (isset($validated['full_name']))
                        $contextData['full_name_in_company'] = $validated['full_name'];
                    if (isset($validated['status']))
                        $contextData['status'] = $validated['status'];
                    if (isset($validated['balance']) && $isSuperAdmin) {
                        // تحديث رصيد الخزنة عهدة الموظف
                        $defaultBox = \App\Models\CashBox::withoutGlobalScopes()
                            ->where('user_id', $user->id)
                            ->where('company_id', $activeCompanyId)
                            ->first();
                        if ($defaultBox) {
                            $currentBalance = (float)$defaultBox->balance;
                            $newBalance = (float)$validated['balance'];
                            $difference = $newBalance - $currentBalance;

                            if ($difference !== 0) {
                                $defaultBox->balance = $newBalance;
                                $defaultBox->save();

                                // تسجيل حركة الخزنة
                                \App\Models\Transaction::create([
                                    'user_id' => $user->id,
                                    'cashbox_id' => $defaultBox->id,
                                    'company_id' => $activeCompanyId,
                                    'type' => $difference > 0 ? 'deposit' : 'withdraw',
                                    'amount' => abs($difference),
                                    'balance_before' => $currentBalance,
                                    'balance_after' => $newBalance,
                                    'created_by' => $authUser->id,
                                    'description' => 'تعديل رصيد الخزنة نقداً للموظف',
                                ]);
                            }
                        }
                    }
                    if (isset($validated['customer_type']))
                        $contextData['customer_type_in_company'] = $validated['customer_type'];
                    if (isset($validated['position']))
                        $contextData['position_in_company'] = $validated['position'];

                    if (!empty($contextData)) {
                        $companyUser->update($contextData);
                    }

                    // مزامنة العلاقات التجارية (Business Relations)
                    if ($request->has('relation_types')) {
                        $relationTypes = (array)$request->input('relation_types');
                        $userRelations = [];
                        foreach (array_unique($relationTypes) as $type) {
                            \Modules\Companies\Models\BusinessRelation::firstOrCreate([
                                'company_id' => $activeCompanyId,
                                'user_id' => $user->id,
                                'relation_type' => $type,
                            ]);
                            $userRelations[] = $type;
                        }
                        // حذف العلاقات التي لم تعد موجودة
                        \Modules\Companies\Models\BusinessRelation::where([
                            'company_id' => $activeCompanyId,
                            'user_id' => $user->id,
                        ])->whereNotIn('relation_type', $userRelations)->delete();
                    }

                    // مزامنة الأرصدة الافتتاحية للأطراف
                    if ($request->has('starting_balances')) {
                        $startingBalances = (array)$request->input('starting_balances');
                        foreach ($startingBalances as $relType => $amount) {
                            $balModel = \Modules\Companies\Models\StakeholderFinancialBalance::firstOrCreate([
                                'company_id' => $activeCompanyId,
                                'user_id' => $user->id,
                                'relation_type' => $relType,
                            ]);

                            $currentVal = (float)$balModel->balance;
                            $newVal = (float)$amount;
                            $diff = $newVal - $currentVal;

                            if ($diff != 0) {
                                $balModel->balance = $newVal;
                                $balModel->save();

                                // تسجيل التغيير في الحركات كحركة تعديل رصيد دفتري
                                \App\Models\Transaction::create([
                                    'user_id' => $user->id,
                                    'cashbox_id' => null, // حركة ذمم دفترية
                                    'company_id' => $activeCompanyId,
                                    'type' => $diff > 0 ? 'deposit' : 'withdraw',
                                    'amount' => $diff,
                                    'balance_before' => $currentVal,
                                    'balance_after' => $newVal,
                                    'created_by' => $authUser->id,
                                    'description' => 'تعديل رصيد افتتاحي - ' . ($relType === 'receivable' ? 'ذمة مدينة عميل' : 'ذمة دائنة مورد'),
                                ]);
                            }
                        }
                    }
                }
            }

            if ($request->has('images_ids')) {
                $user->syncImages($request->input('images_ids'), 'avatar');
            }

            // 3. مزامنة الشركات (Multi-Company Sync)
            if ($request->has('company_ids')) {
                $companyIds = array_filter((array) $request->input('company_ids'));

                if ($isSuperAdmin) {
                    // السوبر أدمن يمكنه التحكم في كافة الشركات (مزامنة كاملة)
                    $user->companies()->sync($companyIds);
                } else {
                    // مدير الشركة يمكنه فقط التحكم في الشركات التي يديرها هو
                    $myManagedCompanyIds = $authUser->companies()->pluck('companies.id')->toArray();

                    // الشركات الحالية للمستخدم والتي لا يملك المدير سلطة عليها (يجب الحفاظ عليها)
                    $othersCompanyIds = $user->companies()
                        ->whereNotIn('companies.id', $myManagedCompanyIds)
                        ->pluck('companies.id')
                        ->toArray();

                    // الشركات المختارة والتي يملك المدير سلطة عليها
                    $allowedSelectedIds = array_intersect($companyIds, $myManagedCompanyIds);

                    // القائمة النهائية = (ما لا يملكه المدير) + (ما اختاره المدير مما يملكه)
                    $finalSyncIds = array_unique(array_merge($othersCompanyIds, $allowedSelectedIds));

                    $user->companies()->syncWithPivotValues($finalSyncIds, [
                        'created_by' => $authUser->id,
                        'status' => 'active'
                    ]);
                }
            }

            // مزامنة الفروع (Multi-Branch Sync)
            if ($request->has('branch_ids')) {
                $branchIds = array_filter((array) $request->input('branch_ids'));
                
                // الحصول على كافة الشركات التي ينتمي إليها المستخدم المستهدف حالياً (بعد مزامنة الشركات)
                $targetCompanyIds = $user->companies()->pluck('companies.id')->toArray();
                
                if ($isSuperAdmin) {
                    // السوبر أدمن يمكنه إدارة فروع كافة شركات المستخدم
                    $validBranchIds = \Modules\Companies\Models\Branch::withoutGlobalScope('company_filter')
                        ->whereIn('id', $branchIds)
                        ->whereIn('company_id', $targetCompanyIds)
                        ->pluck('id')
                        ->toArray();
                        
                    $user->branches()->sync($validBranchIds);
                } else {
                    // مدير الشركة يمكنه فقط إدارة الفروع التابعة للشركات التي يديرها هو
                    $myManagedCompanyIds = $authUser->companies()->pluck('companies.id')->toArray();
                    
                    // 1. الفروع الحالية للمستخدم والتي تنتمي لشركات لا يديرها هذا المدير (يجب الحفاظ عليها)
                    $otherBranchesIds = $user->branches()
                        ->withoutGlobalScope('company_filter')
                        ->whereNotIn('branches.company_id', $myManagedCompanyIds)
                        ->pluck('branches.id')
                        ->toArray();
                        
                    // 2. الفروع المختارة من الطلب والتي تنتمي لشركات يديرها المدير ومسندة للمستخدم المستهدف
                    $allowedCompanyIds = array_intersect($targetCompanyIds, $myManagedCompanyIds);
                    $allowedSelectedBranchIds = \Modules\Companies\Models\Branch::withoutGlobalScope('company_filter')
                        ->whereIn('id', $branchIds)
                        ->whereIn('company_id', $allowedCompanyIds)
                        ->pluck('id')
                        ->toArray();
                        
                    // القائمة النهائية = (الفروع التي يجب الحفاظ عليها) + (الفروع المختارة المسموح بها)
                    $finalBranchIds = array_unique(array_merge($otherBranchesIds, $allowedSelectedBranchIds));
                    
                    $user->branches()->sync($finalBranchIds);
                }
            }

            // 4. تحديث الأدوار والصلاحيات (سياق الشركة المعطاة أو النشطة)
            $targetCompanyId = $request->input('sync_company_id', $activeCompanyId);

            if ($targetCompanyId && !$isUpdatingSelf) {
                $originalTeamId = getPermissionsTeamId();
                setPermissionsTeamId($targetCompanyId);

                if ($request->has('roles')) {
                    $requestedRoles = $validated['roles'];
                    if (!$isSuperAdmin) {
                        $myRoles = $authUser->getRoleNames()->toArray();
                        $unauthorizedRoles = array_diff($requestedRoles, $myRoles);
                        if (!empty($unauthorizedRoles)) {
                            setPermissionsTeamId($originalTeamId);
                            return api_forbidden('لا يمكنك منح أدوار لا تملكها: ' . implode(', ', $unauthorizedRoles));
                        }
                    }
                    $user->syncRoles($requestedRoles);
                }

                if ($request->has('permissions')) {
                    $requestedPermissions = $validated['permissions'];
                    if (!$isSuperAdmin) {
                        $myPermissions = $authUser->getAllPermissions()->pluck('name')->toArray();
                        $unauthorizedPermissions = array_diff($requestedPermissions, $myPermissions);
                        if (!empty($unauthorizedPermissions)) {
                            setPermissionsTeamId($originalTeamId);
                            return api_forbidden('لا يمكنك منح صلاحيات لا تملكها: ' . implode(', ', $unauthorizedPermissions));
                        }
                    }
                    $user->syncPermissions($requestedPermissions);
                }

                setPermissionsTeamId($originalTeamId);
            }

            DB::commit();
            return api_success(new UserResource($user->load(array_merge($this->relations, ['roles', 'permissions']))), 'تم تحديث البيانات بنجاح.');
        } catch (Throwable $e) {
            DB::rollback();
            return api_exception($e);
        }
    }

    /**
     * @group 07. الإدارة وسجلات النظام
     * 
     * حذف مستخدمين (Batch)
     * 
     * @bodyParam item_ids integer[] required مصفوفة المعرفات. Example: [2, 3]
     */
    public function destroy(Request $request, User $user = null)
    {
        $authUser = Auth::user();
        if (!$authUser) {
            return api_unauthorized('يجب تسجيل الدخول.');
        }

        if ($user && $user->exists) {
            $userIds = [$user->id];
        } else {
            $userIds = $request->input('item_ids');
            if (is_numeric($userIds)) {
                $userIds = [(int)$userIds];
            }
        }

        if (!$userIds || !is_array($userIds) || empty($userIds)) {
            return api_error('لم يتم تحديد معرفات المستخدمين بشكل صحيح', [], 400);
        }

        DB::beginTransaction();
        try {
            $usersToDelete = User::withoutGlobalScopes()->whereIn('id', $userIds)->get();
            $activeCompanyId = $authUser->active_company_id;
            $isSuperAdmin = $authUser->hasPermissionTo(perm_key('admin.super'));
            $isCompanyAdmin = $authUser->hasPermissionTo(perm_key('admin.company'));
            $canDeleteAll = $authUser->hasPermissionTo(perm_key('users.delete_all'));
            $canDeleteChildren = $authUser->hasPermissionTo(perm_key('users.delete_children'));

            $deletedCount = 0;
            $skippedCount = 0;
            $skipReasons = [];
            $descendantUserIds = [];

            if ($canDeleteChildren) {
                $descendantUserIds = $authUser->getDescendantUserIds();
            }

            foreach ($usersToDelete as $user) {
                /** @var \App\Models\User $user */
                if ($user->id === $authUser->id) {
                    continue;
                }

                // 1. فحص الأمان المالي والقيود أولاً في كل الحالات (للشركة النشطة)
                if ($activeCompanyId) {
                    $deletionSafetyCheck = $user->hasActiveTransactionsInCompany($activeCompanyId);

                    if ($deletionSafetyCheck !== null) {
                        $skippedCount++;
                        $skipReasons[] = [
                            'user_id' => $user->id,
                            'username' => $user->username ?: $user->nickname,
                            'reason' => $deletionSafetyCheck['message'],
                        ];
                        Log::warning("تم تخطي حذف/فصل المستخدم {$user->id} بسبب: {$deletionSafetyCheck['message']}");
                        continue;
                    }
                }

                // تحديد نوع الحذف المطلوب
                $deleteType = $request->input('delete_type', 'company');
                $shouldGlobalDelete = ($deleteType === 'global') && ($isSuperAdmin || $canDeleteAll);

                if ($shouldGlobalDelete) {
                    // 2. حذف نهائي كلي من النظام (Hard Delete)
                    $user->cashBoxes()->delete();
                    $user->companyUsers()->delete();
                    $user->delete();
                    $deletedCount++;
                } else {
                    // 3. فك ارتباط بالشركة النشطة فقط (Un-link)
                    if ($activeCompanyId && ($isSuperAdmin || $isCompanyAdmin || ($canDeleteChildren && in_array($user->id, $descendantUserIds)))) {
                        $companyUser = $user->companyUsers()->where('company_id', $activeCompanyId)->first();

                        if ($companyUser) {
                            $companyUser->delete();
                            $deletedCount++;

                            // الحذف النهائي التلقائي للمستخدم من جدول users إذا لم يعد لديه ارتباط بأي شركة أخرى
                            if ($user->companyUsers()->count() === 0) {
                                $user->delete();
                            }
                        }
                    }
                }
            }

            // **[منطق إرجاع الخطأ]:** إذا لم يتم حذف أي مستخدم (سواء بسبب الصلاحيات أو التخطي)
            if ($deletedCount === 0) {
                DB::rollBack();
                $message = 'لم يتم حذف أي مستخدمين.';
                $data = []; // البيانات التي سترجع للواجهة الأمامية

                if ($skippedCount > 0) {
                    $message .= " تم تخطي {$skippedCount} مستخدم لوجود سجلات حركية/مالية مرتبطة بالشركة النشطة، ولا يمكن فصلهم.";
                    $data['skipped_users'] = $skipReasons;
                } else {
                    $message .= " تحقق من الصلاحيات أو معرفات المستخدمين.";
                }

                return api_error($message, $data, 403);
            }

            // **[منطق إرجاع النجاح]:** عند نجاح عملية الحذف
            DB::commit();
            $data = ($skippedCount > 0) ? ['skipped_users' => $skipReasons] : [];
            $message = "تم معالجة حذف {$deletedCount} مستخدم بنجاح" . ($skippedCount > 0 ? " مع تخطي {$skippedCount} مستخدم لوجود سجلات حركية." : "");

            return api_success($data, $message);
        } catch (Throwable $e) {
            DB::rollback();
            Log::error("فشل حذف المستخدم: " . $e->getMessage(), ['exception' => $e, 'user_id' => $authUser->id, 'item_ids' => $userIds]);
            return api_exception($e);
        }
    }

    /**
     * @group 07. الإدارة وسجلات النظام
     * 
     * تغيير الشركة النشطة
     * 
     * @urlParam user required معرف المستخدم. Example: 1
     * @bodyParam company_id integer required معرف الشركة. Example: 2
     */
    public function changeCompany(Request $request, $userId)
    {
        $user = User::withoutGlobalScopes()->findOrFail($userId);
        $authUser = Auth::user();

        if (!$authUser) {
            return api_unauthorized('يجب تسجيل الدخول.');
        }

        if (
            !$authUser->hasPermissionTo(perm_key('admin.super')) &&
            !$authUser->hasPermissionTo(perm_key('users.update_all')) &&
            $authUser->id !== $user->id
        ) {
            return api_forbidden('ليس لديك صلاحية لتغيير شركة هذا المستخدم.');
        }

        $validated = $request->validate([
            'company_id' => 'present|nullable|integer|exists:companies,id',
        ]);

        DB::beginTransaction();
        try {
            $newCompanyId = $validated['company_id'] ?? null;

            if ($newCompanyId) {
                $companyUserExists = CompanyUser::withoutGlobalScopes()->where('user_id', $user->id)
                    ->where('company_id', $newCompanyId)
                    ->exists();

                if (!$companyUserExists && !$user->hasPermissionTo(perm_key('admin.super'))) {
                    DB::rollback();
                    return api_error('المستخدم غير مرتبط بالشركة المحددة.', [], 400);
                }

                // جلب الفرع الافتراضي للشركة الجديدة
                $defaultBranch = \Modules\Companies\Models\Branch::where('company_id', $newCompanyId)
                    ->where('is_default', true)
                    ->first();

                $user->update([
                    'active_company_id' => $newCompanyId,
                    'branch_id' => $defaultBranch ? $defaultBranch->id : null
                ]);
            } else {
                if (!$user->hasPermissionTo(perm_key('admin.super'))) {
                    DB::rollback();
                    return api_error('المستخدم غير مصرح له بتعطيل الشركة النشطة.', [], 400);
                }

                $user->update([
                    'active_company_id' => null,
                    'branch_id' => null
                ]);
            }

            $user->load('activeCompanyUser.company');
            DB::commit();

            return api_success(new UserResource($user), 'تم تغيير الشركة النشطة للمستخدم بنجاح.');
        } catch (Throwable $e) {
            DB::rollback();
            Log::error("فشل تغيير شركة المستخدم: " . $e->getMessage(), ['exception' => $e, 'user_id' => $authUser->id, 'target_user_id' => $user->id, 'request_data' => $request->all()]);
            return api_exception($e);
        }
    }

    /**
     * البحث عن المستخدمين بناءً على الفلاتر والصلاحيات.
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function usersSearch(Request $request)
    {
        $authUser = Auth::user();

        try {
            if (!$authUser) {
                return api_unauthorized('يجب تسجيل الدخول.');
            }

            $activeCompanyId = $authUser->active_company_id;
            $isSuperAdmin    = $authUser->hasPermissionTo(perm_key('admin.super'));
            $isCompanyAdmin  = $authUser->hasPermissionTo(perm_key('admin.company'));
            $canViewAll      = $authUser->hasPermissionTo(perm_key('users.view_all'));
            $canViewChildren = $authUser->hasPermissionTo(perm_key('users.view_children'));
            $canViewSelf     = $authUser->hasPermissionTo(perm_key('users.view_self'));

            $perPage   = max(1, $request->input('per_page', 10));
            $sortField = $request->input('sort_by', 'id');
            $sortOrder = $request->input('sort_order', 'asc');

            // ======================================================
            // السوبر أدمن: يرى جميع المستخدمين بدون قيود (User model)
            // ======================================================
            if ($isSuperAdmin) {
                $query = User::query()
                    ->withoutGlobalScope('company_filter')
                    ->withoutGlobalScope('branch_filter')
                    ->with(['company', 'companies.logo', 'creator', 'roles', 'images', 'cashBoxes']);

                if ($request->filled('search')) {
                    $search  = $request->input('search');
                    $columns = ['username', 'email', 'phone', 'full_name', 'nickname'];
                    $query->smartSearch($search, $columns);
                }

                $query
                    ->when($request->filled('status'), fn($q) =>
                        $q->where('status', $request->input('status')))
                    ->when($request->filled('phone'), fn($q) =>
                        $q->where('phone', 'like', '%' . $request->phone . '%'))
                    ->when($request->filled('email'), fn($q) =>
                        $q->where('email', 'like', '%' . $request->email . '%'));

                $allowedSortFields = ['id', 'full_name', 'nickname', 'username', 'email', 'phone', 'created_at'];
                $query->orderBy(in_array($sortField, $allowedSortFields) ? $sortField : 'id', $sortOrder);

                /** @var \Illuminate\Pagination\LengthAwarePaginator $users */
                $users = $query->paginate($perPage);

                // تحسين التشابه (Similarity Matching)
                if ($request->filled('search')) {
                    $search  = $request->input('search');
                    $items   = $users->getCollection();
                    $refined = (new User())->refineSimilarity($items, $search, ['full_name', 'nickname', 'username', 'email', 'phone'], 80);
                    if ($refined && !$refined->isEmpty()) {
                        $users->setCollection($refined);
                    }
                }

                if ($users->isEmpty()) {
                    return api_success([], 'لم يتم العثور على مستخدمين.');
                }

                return api_success(UserResource::collection($users), 'تم جلب المستخدمين بنجاح.');
            }

            // ======================================================
            // بقية المستخدمين: يعملون في نطاق الشركة النشطة (CompanyUser)
            // ======================================================
            if (!$activeCompanyId) {
                return api_forbidden('يجب تحديد شركة نشطة.');
            }

            $baseQuery = CompanyUser::query()
                ->with([
                    'user' => fn($q) => $q->with([
                        'cashBoxes' => function ($cashBoxQuery) use ($activeCompanyId) {
                            $cashBoxQuery->where('company_id', $activeCompanyId);
                        },
                        'creator',
                        'companies.logo'
                    ]),
                    'company',
                ])
                ->where('company_id', $activeCompanyId);

            if ($isCompanyAdmin || $canViewAll) {
                // يرى الكل في شركته
            } elseif ($canViewChildren) {
                $descendantUserIds = $authUser->getDescendantUserIds();
                $baseQuery->whereIn('user_id', $descendantUserIds);
            } elseif ($canViewSelf) {
                $baseQuery->where('user_id', $authUser->id);
            } else {
                return api_forbidden('ليس لديك صلاحية للبحث عن المستخدمين في هذه الشركة.');
            }

            if ($request->filled('search')) {
                $search         = $request->input('search');
                $columns        = ['nickname_in_company', 'full_name_in_company'];
                $relationColumns = ['user' => ['email', 'phone', 'username', 'full_name', 'nickname']];
                $baseQuery->smartSearch($search, $columns, $relationColumns);
            }

            $baseQuery
                ->when($request->filled('nickname'), fn($q) =>
                    $q->where('nickname_in_company', 'like', '%' . $request->nickname . '%'))
                ->when($request->filled('email'), fn($q) =>
                    $q->whereHas('user', fn($u) =>
                        $u->where('email', 'like', '%' . $request->email . '%')))
                ->when($request->filled('phone'), fn($q) =>
                    $q->whereHas('user', fn($u) =>
                        $u->where('phone', 'like', '%' . $request->phone . '%')))
                ->when($request->filled('status'), fn($q) =>
                    $q->where('status', $request->input('status')))
                ->when($request->filled('created_at_from'), fn($q) =>
                    $q->where('company_user.created_at', '>=', $request->input('created_at_from') . ' 00:00:00'))
                ->when($request->filled('created_at_to'), fn($q) =>
                    $q->where('company_user.created_at', '<=', $request->input('created_at_to') . ' 23:59:59'));

            if (in_array($sortField, ['nickname_in_company', 'status', 'position_in_company', 'customer_type_in_company', 'full_name_in_company'])) {
                $baseQuery->orderBy('company_user.' . $sortField, $sortOrder);
            } elseif (in_array($sortField, ['username', 'email', 'phone'])) {
                $baseQuery->join('users', 'company_user.user_id', '=', 'users.id')
                    ->orderBy('users.' . $sortField, $sortOrder)
                    ->select('company_user.*');
            } else {
                $baseQuery->orderBy('company_user.id', $sortOrder);
            }

            /** @var \Illuminate\Pagination\LengthAwarePaginator $companyUsers */
            $companyUsers = $baseQuery->paginate($perPage);

            // تحسين التشابه (Similarity Matching)
            if ($request->filled('search')) {
                $search  = $request->input('search');
                $items   = $companyUsers->getCollection();
                $fields  = ['nickname_in_company', 'full_name_in_company', 'user.email', 'user.phone', 'user.username', 'user.full_name', 'user.nickname'];
                $refined = (new CompanyUser())->refineSimilarity($items, $search, $fields, 80);

                if ($refined) {
                    $companyUsers->setCollection($refined);
                }
            }

            if ($companyUsers->isEmpty()) {
                return api_success([], 'لم يتم العثور على مستخدمين.');
            }

            return api_success(CompanyUserBasicResource::collection($companyUsers), 'تم جلب المستخدمين بنجاح.');
        } catch (Throwable $e) {
            Log::error("فشل البحث عن المستخدمين: " . $e->getMessage(), [
                'exception' => $e,
                'user_id' => $authUser->id ?? null,
                'request_data' => $request->all()
            ]);

            return api_exception($e);
        }
    }

    /**
     * @group 07. الإدارة وسجلات النظام
     * 
     * إحصائيات المستخدمين
     */
    public function stats(Request $request)
    {
        try {
            /** @var \App\Models\User $authUser */
            $authUser = Auth::user();
            if (!$authUser)
                return api_unauthorized();

            $activeCompanyId = $authUser->active_company_id;
            $isSuperAdmin = $authUser->hasPermissionTo(perm_key('admin.super'));
            $isGlobal = filter_var($request->input('global', false), FILTER_VALIDATE_BOOLEAN) && $isSuperAdmin;

            $query = CompanyUser::query();

            if (!$isGlobal && $activeCompanyId) {
                $query->where('company_id', $activeCompanyId);
            }

            $total = (clone $query)->count();
            $active = (clone $query)->where('status', 'active')->count();
            $inactive = (clone $query)->where('status', 'inactive')->count();

            // Admins (has any admin role)
            $admins = (clone $query)->whereHas('user.roles', function ($q) {
                $q->whereIn('name', ['admin.super', 'admin.company']);
            })->count();

            return api_success([
                'total' => $total,
                'active' => $active,
                'inactive' => $inactive,
                'admins' => $admins,
            ]);
        } catch (Throwable $e) {
            return api_exception($e);
        }
    }
}
