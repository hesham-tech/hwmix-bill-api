<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Resources\User\UserResource;
use App\Http\Resources\User\UserWithPermissionsResource;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException; // استيراد ValidationException
use Throwable; // استيراد Throwable
use App\Http\Requests\Auth\ForgotPasswordRequest;
use App\Http\Requests\Auth\ResetPasswordRequest;
use App\Actions\Auth\SendForgotPasswordOtpAction;
use App\Actions\Auth\ResetPasswordAction;
use App\Actions\Auth\VerifyForgotPasswordOtpAction;

/**
 * Class AuthController
 *
 * تحكم في عمليات التسجيل وتسجيل الدخول للمستخدمين
 *
 * @package App\Http\Controllers
 */
class AuthController extends Controller
{
    /**
     * @group 01. إدارة المصادقة
     * 
     * تسجيل مستخدم جديد
     * 
     * إنشاء حساب مستخدم جديد وربطه بالشركة الافتراضية.
     * 
     * @bodyParam phone string required رقم الهاتف (يجب أن يكون فريداً). Example: 01099223344
     * @bodyParam password string required كلمة المرور (8 أحرف على الأقل). Example: password123
     * @bodyParam full_name string الاسم الكامل للمستخدم. Example: هشام محمد
     * @bodyParam nickname string الاسم الحركي أو اللقب. Example: أبو هيبة
     * @bodyParam email string البريد الإلكتروني (اختياري وفريد). Example: user@example.com
     * 
     * @response 201 {
     *  "success": true,
     *  "data": { "user": { "id": 1, "full_name": "..." }, "token": "..." },
     *  "message": "تم تسجيل المستخدم بنجاح."
     * }
     */
    public function register(\App\Http\Requests\Auth\RegisterRequest $request): JsonResponse
    {
        \Illuminate\Support\Facades\DB::beginTransaction();
        try {
            $validated = $request->validated();

            \Log::info('Registration Attempt', ['phone' => $validated['phone']]);

            // 1. تحديد الشركة الافتراضية
            $company = \App\Models\Company::first();
            $companyId = $company ? $company->id : 1;

            // 2. البحث عن مستخدم موجود مسبقاً في النظام بالكامل
            $user = User::withoutGlobalScope('company')
                ->where(function ($q) use ($validated) {
                    $q->where('phone', $validated['phone']);
                    if (!empty($validated['email'])) {
                        $q->orWhere('email', $validated['email']);
                    }
                })->first();

            if ($user) {
                // التحقق من عدم الارتباط المسبق بنفس الشركة
                $exists = \App\Models\CompanyUser::where('user_id', $user->id)
                    ->where('company_id', $companyId)
                    ->exists();

                if ($exists) {
                    \Illuminate\Support\Facades\DB::rollBack();
                    return api_error('هذا الحساب مسجل بالفعل في هذه الشركة.', ['phone' => $validated['phone']], 409);
                }
                \Log::info('Existing user found, linking to company', ['user_id' => $user->id]);
            } else {
                // 3. إنشاء مستخدم عالمي جديد
                $user = User::create([
                    'phone' => $validated['phone'],
                    'email' => $validated['email'] ?? null,
                    'active_company_id' => $companyId,
                    'full_name' => $validated['full_name'],
                    'nickname' => $validated['nickname'] ?? $validated['full_name'],
                    'password' => Hash::make($validated['password']),
                ]);
                \Log::info('New user created via registration', ['user_id' => $user->id]);
            }

            // 4. إنشاء سجل العلاقة مع الشركة (Contextual Data)
            $companyUser = \App\Models\CompanyUser::updateOrCreate([
                'user_id' => $user->id,
                'company_id' => $companyId,
            ], [
                'nickname_in_company' => $validated['nickname'] ?? $user->nickname,
                'full_name_in_company' => $validated['full_name'] ?? $user->full_name,
                'status' => 'active',
                'created_by' => $user->id, // يسجل نفسه كمنشئ للعلاقة
            ]);

            // 5. ربط الفرع الافتراضي تلقائياً
            $defaultBranch = \Modules\Companies\Models\Branch::where('company_id', $companyId)
                ->where('is_default', true)
                ->first();
            if ($defaultBranch) {
                $user->branches()->syncWithoutDetaching([$defaultBranch->id]);
            }

            \Illuminate\Support\Facades\DB::commit();

            // 6. إطلاق الأحداث وإنشاء التوكن
            event(new \App\Events\UserCreated($user));

            $token = $user->createToken('auth_token')->plainTextToken;
            $user->load(['roles.permissions', 'permissions', 'branches', 'company.logo']);

            return api_success([
                'user' => new UserWithPermissionsResource($user),
                'token' => $token,
            ], 'تم تسجيل الحساب بنجاح.', 201);

        } catch (Throwable $e) {
            \Illuminate\Support\Facades\DB::rollBack();
            \Log::error('Registration Error: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return api_exception($e, 500);
        }
    }


    /**
     * @group 01. إدارة المصادقة
     * 
     * تسجيل دخول
     * 
     * الحصول على رمز الوصول (Access Token) باستخدام الهاتف أو البريد الإلكتروني.
     * 
     * @bodyParam login string required الهاتف أو البريد الإلكتروني. Example: 01099223344
     * @bodyParam password string required كلمة المرور. Example: password123
     * 
     * @response 200 {
     *  "success": true,
     *  "data": { "token": "...", "user": {...} },
     *  "message": "تم تسجيل دخول المستخدم بنجاح."
     * }
     */
    public function login(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'login' => 'required',
                'password' => 'required',
                'remember' => 'nullable|boolean',
            ]);

            $loginField = filter_var($validated['login'], FILTER_VALIDATE_EMAIL) ? 'email' : 'phone';
            \Log::info('Login attempt started', ['field' => $loginField, 'value' => $validated['login']]);

            $user = User::where($loginField, $validated['login'])->first();
            if (!$user) {
                \Log::warning('Login failed: User not found in database', ['login' => $validated['login']]);
                return api_error('بيانات الاعتماد غير صالحة.', [], 422);
            }

            \Log::info('User found, checking password', ['user_id' => $user->id]);
            if (!Hash::check($validated['password'], $user->password)) {
                \Log::warning('Login failed: Password hashing mismatch', ['user_id' => $user->id]);
                return api_error('بيانات الاعتماد غير صالحة.', [], 422);
            }

            if (!Auth::attempt([$loginField => $validated['login'], 'password' => $validated['password']])) {
                \Log::error('Login failed: Auth::attempt returned false but Hash::check passed', ['user_id' => $user->id]);
                return api_error('بيانات الاعتماد غير صالحة.', [], 422);
            }
            \Log::info('Login successful', ['user_id' => $user->id]);

            /** @var \App\Models\User $user */
            $user = Auth::user();

            $remember = $request->boolean('remember');
            $expiresAt = $remember ? null : now()->addHours(24);
            $deviceName = $request->header('User-Agent') ?: 'Unknown Device';

            $token = $user->createToken($deviceName, ['*'], $expiresAt)->plainTextToken;

            $user->load(['roles.permissions', 'permissions', 'branches', 'company.logo']);

            return api_success([
                'user' => new UserWithPermissionsResource($user),
                'token' => $token,
            ], 'تم تسجيل دخول المستخدم بنجاح.');
        } catch (ValidationException $e) {
            return api_error('فشل التحقق من صحة البيانات أثناء تسجيل الدخول.', $e->errors(), 422);
        } catch (Throwable $e) {
            return api_exception($e, 500);
        }
    }

    /**
     * @group 01. إدارة المصادقة
     * 
     * تسجيل الخروج
     * 
     * إبطال رمز الوصول الحالي للمستخدم.
     */
    public function logout(Request $request): JsonResponse
    {
        try {
            /** @var \App\Models\User $user */
            /** @var \Laravel\Sanctum\PersonalAccessToken|null $token */
            $user = $request->user();
            if ($user) {
                /** @var \Laravel\Sanctum\PersonalAccessToken $token */
                $token = $user->currentAccessToken();
                $token->delete();
            } else {
                // إذا لم يكن هناك مستخدم مصادق عليه، فلا يوجد رمز مميز لحذفه
                return api_error('لا يوجد مستخدم مصادق عليه لتسجيل الخروج.', [], 401);
            }

            return api_success([], 'تم تسجيل الخروج بنجاح.');
        } catch (Throwable $e) {
            return api_exception($e, 500);
        }
    }

    /**
     * @group 01. إدارة المصادقة
     * 
     * بياناتي (الملف الشخصي)
     * 
     * استعادة بيانات المستخدم المصادق عليه حالياً.
     */
    public function me(Request $request): JsonResponse
    {
        try {
            /** @var \App\Models\User $user */
            $user = $request->user();

            if (!$user) {
                return api_unauthorized('المستخدم غير مصادق عليه.');
            }

            $user->load(['company.logo', 'companies.logo', 'roles.permissions', 'permissions', 'branches']);

            return api_success(new UserWithPermissionsResource($user), 'تم استرداد بيانات المستخدم بنجاح.');
        } catch (Throwable $e) {
            return api_exception($e, 500);
        }
    }

    /**
     * @group 01. إدارة المصادقة
     * 
     * فحص حالة تسجيل الدخول
     */
    public function checkLogin(Request $request): JsonResponse
    {
        try {
            /** @var \App\Models\User $user */
            $user = Auth::user();

            if (Auth::check()) {
                return api_success(new UserWithPermissionsResource($user), 'المستخدم مسجل الدخول.');
            }

            return api_unauthorized('المستخدم غير مصادق عليه.');
        } catch (Throwable $e) {
            return api_exception($e, 500);
        }
    }

    /**
     * @group 01. إدارة المصادقة
     * 
     * قائمة الجلسات النشطة
     * 
     * استرجاع جميع الأجهزة المسجل الدخول منها حالياً.
     */
    public function listTokens(Request $request): JsonResponse
    {
        try {
            $user = $request->user();
            $tokens = $user->tokens()->orderBy('last_used_at', 'desc')->get()->map(function ($token) use ($user) {
                /** @var \Laravel\Sanctum\PersonalAccessToken $currentToken */
                $currentToken = $user->currentAccessToken();
                return [
                    'id' => $token->id,
                    'device' => $token->name,
                    'last_used_at' => $token->last_used_at,
                    'created_at' => $token->created_at,
                    'is_current' => $token->id === $currentToken->id,
                ];
            });

            return api_success($tokens, 'تم استرداد قائمة الجلسات بنجاح.');
        } catch (Throwable $e) {
            return api_exception($e, 500);
        }
    }

    /**
     * @group 01. إدارة المصادقة
     * 
     * حذف جلسة محددة
     * 
     * تسجيل الخروج من جهاز معين.
     */
    public function revokeToken(Request $request, $id): JsonResponse
    {
        try {
            $user = $request->user();
            $token = $user->tokens()->where('id', $id)->first();

            if (!$token) {
                return api_error('الجلسة غير موجودة.', [], 404);
            }

            $token->delete();

            return api_success([], 'تم حذف الجلسة وتسجيل الخروج بنجاح.');
        } catch (Throwable $e) {
            return api_exception($e, 500);
        }
    }

    /**
     * @group 01. إدارة المصادقة
     * 
     * تسجيل الخروج من جميع الأجهزة الأخرى
     */
    public function revokeAllOtherTokens(Request $request): JsonResponse
    {
        try {
            $user = $request->user();
            /** @var \Laravel\Sanctum\PersonalAccessToken $currentToken */
            $currentToken = $user->currentAccessToken();
            $currentTokenId = $currentToken->id;

            $user->tokens()->where('id', '!=', $currentTokenId)->delete();

            return api_success([], 'تم تسجيل الخروج من جميع الأجهزة الأخرى بنجاح.');
        } catch (Throwable $e) {
            return api_exception($e, 500);
        }
    }

    /**
     * @group 01. إدارة المصادقة
     * 
     * طلب استعادة كلمة المرور وإرسال رمز OTP
     * 
     * @bodyParam email string required البريد الإلكتروني للمستخدم. Example: user@example.com
     */
    public function forgotPassword(ForgotPasswordRequest $request, SendForgotPasswordOtpAction $action): JsonResponse
    {
        try {
            $action->execute($request->email, $request->frontend_url);
            return api_success([], 'تم إرسال رمز التحقق (OTP) إلى بريدك الإلكتروني بنجاح.');
        } catch (Throwable $e) {
            return api_error($e->getMessage(), [], 422);
        }
    }

    /**
     * @group 01. إدارة المصادقة
     * 
     * إعادة تعيين كلمة المرور باستخدام رمز الـ OTP
     * 
     * @bodyParam email string required البريد الإلكتروني. Example: user@example.com
     * @bodyParam otp string required رمز التحقق المكون من 6 أرقام. Example: 123456
     * @bodyParam password string required كلمة المرور الجديدة. Example: password123
     * @bodyParam password_confirmation string required تأكيد كلمة المرور الجديدة. Example: password123
     */
    public function resetPassword(ResetPasswordRequest $request, ResetPasswordAction $action): JsonResponse
    {
        try {
            $action->execute($request->email, $request->otp, $request->password);
            return api_success([], 'تم إعادة تعيين كلمة المرور بنجاح، يمكنك الآن تسجيل الدخول.');
        } catch (Throwable $e) {
            return api_error($e->getMessage(), [], 422);
        }
    }

    /**
     * @group 01. إدارة المصادقة
     * 
     * التحقق من رمز الـ OTP وصلاحيته في الخلفية
     * 
     * @bodyParam email string required البريد الإلكتروني. Example: user@example.com
     * @bodyParam otp string required رمز التحقق المكون من 6 أرقام. Example: 123456
     */
    public function verifyOtp(\Illuminate\Http\Request $request, VerifyForgotPasswordOtpAction $action): JsonResponse
    {
        $request->validate([
            'email' => 'required|email|exists:users,email',
            'otp' => 'required|string|size:6',
        ], [
            'email.required' => 'البريد الإلكتروني مطلوب.',
            'email.email' => 'يجب إدخال بريد إلكتروني صالح.',
            'email.exists' => 'البريد الإلكتروني غير مسجل لدينا.',
            'otp.required' => 'رمز التحقق مطلوب.',
            'otp.size' => 'يجب أن يكون رمز التحقق مكوناً من 6 أرقام.',
        ]);

        try {
            $action->execute($request->email, $request->otp);
            return api_success(['valid' => true], 'رمز التحقق صحيح وصالح.');
        } catch (Throwable $e) {
            return api_error($e->getMessage(), [], 422);
        }
    }
}
